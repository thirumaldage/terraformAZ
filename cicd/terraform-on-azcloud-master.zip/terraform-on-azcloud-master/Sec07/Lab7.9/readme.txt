az account set -s <name-of-subscription>
az account show
az account list
terraform init
terraform plan
terraform apply -auto-approve
terraform output -raw pkey