# terraform-on-azcloud
Infrastructure Automation with Terraform &amp; Azure Devops on Azure Cloud
